
# Evylly Bible Study App — Hybrid Multilingual Version (v1.1)

Conteúdo incluído nesta versão:
- Tema roxo + dourado (UI básica)
- Pomodoro, Estudo Ativo (SQ3R, Feynman), Flashcards, Plano 365 (placeholders)
- Cursos teológicos de amostra
- Suporte híbrido: **Português (ARC) offline**, **Inglês (KJV) offline** (samples included)
- Outras línguas carregadas via API (configure `src/config.js`)
- Instruções para adicionar as Bíblias completas (arquivos JSON) se desejar

---
## Como funciona (resumo)
- Se `public/bible_arc.json` existir, a APP carrega ARC offline automaticamente.
- Se `public/bible_kjv.json` existir, a APP carrega KJV offline automaticamente.
- Para outras línguas, configure uma API em `src/config.js` (BIBLE_API_URL) — o app faz requests para essa API quando o usuário selecionar idioma não-offline.

---
## Como publicar no GitHub (passos rápidos)
1. Vá no seu repositório GitHub → Add file → Upload files → selecione todo o conteúdo deste ZIP e **Commit changes**.
2. Vá na Vercel → New Project → conecte com o repositório → Import → Deploy.

---
## Como adicionar as Bíblias completas (se desejar)
1. Obtenha os textos em formato JSON com estrutura sugerida: 
   {
     "Genesis": {"1": {"1": "texto do versículo", "2": "..." }, "2": {...} },
     "Exodus": {...}
   }
2. Salve como `public/bible_arc.json` (para ARC PT-BR) e `public/bible_kjv.json` (para KJV EN).
3. Faça commit no GitHub; o Vercel redeployará automaticamente.

> Nota: Eu incluí **pequenas amostras** (para rodar e testar). Eu não incluí as Bíblias completas neste ZIP por limitações aqui — mas se você quiser, eu te mostro passo a passo como adicionar os arquivos completos (posso gerar instruções e links confiáveis para download público).

---
Se quiser que eu já inclua as Bíblias completas neste repo, me confirme e eu te explico como fornecer os arquivos (ou onde baixá-los legalmente) e então eu os adiciono para você.
