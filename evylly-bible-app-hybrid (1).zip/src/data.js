export const THEOLOGY_MODULES = [
  { id: 1, title: "Introdução à Teologia Bíblica", lessons: [
    {id:1, title:"O que é teologia?", text:"Teologia é o estudo sistemático das verdades bíblicas..."},
    {id:2, title:"Revelação e Escritura", text:"A Bíblia como fonte primária de verdade cristã."}
  ]},
  { id: 2, title: "Hermenêutica Prática", lessons: [
    {id:1, title:"Contexto e Gênero Literário", text:"Entender o gênero ajuda a interpretar o texto."},
    {id:2, title:"Linguagem e Tradução", text:"Atenção às variações de tradução e termos-chave."}
  ]},
  { id: 3, title: "Teologia Sistemática - Resumo", lessons: [
    {id:1, title:"Doutrina de Deus", text:"Deus é uno, eterno, onipotente e pessoal."},
    {id:2, title:"Cristologia", text:"Estudo sobre a pessoa e obra de Cristo."}
  ]}
];

export const READING_PLAN = Array.from({length:365}).map((_,i)=>({day:i+1, title:`Leitura dia ${i+1} - (placeholder)`}));

export const INITIAL_FLASHCARDS = [
  {id:1, front:"O que diz Gênesis 1:1?", back:"No princípio, Deus criou os céus e a terra."},
  {id:2, front:"Qual é a técnica SQ3R?", back:"Survey, Question, Read, Recite, Review"}
];
