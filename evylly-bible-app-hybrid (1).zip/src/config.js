// CONFIG: set API url and default languages
export const DEFAULT_LANGUAGE = 'pt'; // 'pt' = Portuguese (ARC offline), 'en' = English (KJV offline)
export const BIBLE_API_URL = 'https://example-bible-api.org/verse'; // replace with real API URL
export const AVAILABLE_LANGUAGES = [
  { code: 'pt', label: 'Português (ARC)', offlineKey: 'arc' },
  { code: 'en', label: 'English (KJV)', offlineKey: 'kjv' },
  { code: 'es', label: 'Español' },
  { code: 'fr', label: 'Français' },
  { code: 'de', label: 'Deutsch' },
  { code: 'it', label: 'Italiano' },
  { code: 'zh', label: '中文' },
  { code: 'ja', label: '日本語' },
  { code: 'ko', label: '한국어' },
  { code: 'he', label: 'עִברִית' },
  { code: 'gr', label: 'Ελληνικά' }
];
