import axios from 'axios';
import { BIBLE_API_URL } from './config';

export async function fetchVerseFromApi(book, chapter, verse, lang) {
  // Placeholder implementation: you must provide a real BIBLE_API_URL
  // Example query params: ?book=Genesis&chapter=1&verse=1&lang=en
  if (!BIBLE_API_URL || BIBLE_API_URL.includes('example')) {
    return null;
  }
  try {
    const res = await axios.get(BIBLE_API_URL, { params: { book, chapter, verse, lang } });
    return res.data && res.data.text ? res.data.text : null;
  } catch (err) {
    console.error('API error', err);
    return null;
  }
}
