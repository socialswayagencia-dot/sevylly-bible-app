import React, {useEffect, useState} from 'react';
import {AVAILABLE_LANGUAGES, DEFAULT_LANGUAGE} from './config';
import {THEOLOGY_MODULES, READING_PLAN, INITIAL_FLASHCARDS} from './data';
import { fetchVerseFromApi } from './api';

export default function App(){
  const [lang, setLang] = useState(DEFAULT_LANGUAGE);
  const [offlineArc, setOfflineArc] = useState(null);
  const [offlineKjv, setOfflineKjv] = useState(null);
  const [view, setView] = useState('home');
  const [currentVerse, setCurrentVerse] = useState({book:'Genesis', chapter:'1', verse:'1'});
  const [displayText, setDisplayText] = useState('');
  const [pomodoro, setPomodoro] = useState({running:false, mode:'focus', minutes:25, seconds:0});
  const [flashcards, setFlashcards] = useState(INITIAL_FLASHCARDS);

  useEffect(()=>{
    // try load offline files if present
    fetch('/bible_arc.json').then(r=> r.ok ? r.json() : null).then(j=> setOfflineArc(j)).catch(()=>{});
    fetch('/bible_kjv.json').then(r=> r.ok ? r.json() : null).then(j=> setOfflineKjv(j)).catch(()=>{});
  },[]);

  useEffect(()=>{ loadVerse(currentVerse.book, currentVerse.chapter, currentVerse.verse, lang); }, [lang, offlineArc, offlineKjv]);

  async function loadVerse(book, chapter, verse, langCode){
    // If language is Portuguese and offlineArc exists => show from offlineArc
    if(langCode === 'pt' && offlineArc){
      const text = getFromOffline(offlineArc, book, chapter, verse) || null;
      if(text){ setDisplayText(text); return; }
    }
    // If language is English and offlineKjv exists => show from offlineKjv
    if(langCode === 'en' && offlineKjv){
      const text = getFromOffline(offlineKjv, book, chapter, verse) || null;
      if(text){ setDisplayText(text); return; }
    }
    // Otherwise fetch from API (online)
    const apiText = await fetchVerseFromApi(book, chapter, verse, langCode);
    setDisplayText(apiText || 'Versículo não encontrado (tente outra tradução ou conecte API).');
  }

  function getFromOffline(jsonObj, book, chapter, verse){
    try {
      return jsonObj[book] && jsonObj[book][chapter] && jsonObj[book][chapter][verse] ? jsonObj[book][chapter][verse] : null;
    } catch(e){ return null; }
  }

  return (
    <div style={{fontFamily:'Arial, sans-serif', background:'#faf7fd', minHeight:'100vh', color:'#222'}}>
      <header style={{background:'#5b2b8a', color:'#fff', padding:16, display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1 style={{margin:0}}>Evylly Study — Bíblia Híbrida</h1>
        <div>
          <select value={lang} onChange={e=>setLang(e.target.value)} style={{padding:8, borderRadius:6}}>
            {AVAILABLE_LANGUAGES.map(l=> (<option key={l.code} value={l.code}>{l.label}</option>))}
          </select>
        </div>
      </header>
      <main style={{padding:20}}>
        <nav style={{marginBottom:12}}>
          <button onClick={()=>setView('home')} style={navBtn}>Home</button>
          <button onClick={()=>setView('plan')} style={navBtn}>Plano</button>
          <button onClick={()=>setView('pomodoro')} style={navBtn}>Pomodoro</button>
          <button onClick={()=>setView('study')} style={navBtn}>Estudo</button>
          <button onClick={()=>setView('theology')} style={navBtn}>Teologia</button>
        </nav>

        {view==='home' && <Home onOpen={()=>setView('study')} displayText={displayText} setCurrentVerse={setCurrentVerse} />}
        {view==='plan' && <ReadingPlan />}
        {view==='pomodoro' && <Pomodoro pomodoro={pomodoro} setPomodoro={setPomodoro} />}
        {view==='study' && <Study displayText={displayText} setCurrentVerse={setCurrentVerse} addFlash={(f,b)=> setFlashcards(s=>[...s,{id:Date.now(), front:f, back:b}])} />}
        {view==='theology' && <Theology />}

      </main>
      <footer style={{padding:12, textAlign:'center', color:'#6b6b6b'}}>Protótipo híbrido — ARC (pt) & KJV (en) offline (samples) • Outras línguas via API</footer>
    </div>
  );
}

const navBtn = {marginRight:8, padding:'8px 12px', borderRadius:6, border:'none', background:'#fff', cursor:'pointer'};

function Home({onOpen, displayText, setCurrentVerse}){
  return (
    <div>
      <section style={{background:'#fff', padding:16, borderRadius:8}}>
        <h2>Leitura do dia</h2>
        <p>Aberto: Gênesis 1:1</p>
        <div style={{fontStyle:'italic', marginTop:8, background:'#f7f3ff', padding:12, borderRadius:6}}>{displayText || 'Carregando...'}</div>
        <div style={{marginTop:12}}>
          <button onClick={onOpen} style={{...navBtn, background:'#ffd700'}}>Estudar agora</button>
        </div>
      </section>
    </div>
  );
}

function ReadingPlan(){ return (<div style={{background:'#fff', padding:12, borderRadius:8}}><h2>Plano de leitura (365 dias)</h2><ul style={{maxHeight:360, overflow:'auto'}}>{READING_PLAN.map(d=>(<li key={d.day} style={{padding:6, borderBottom:'1px solid #eee'}}>Dia {d.day} — {d.title}</li>))}</ul></div>); }

function Pomodoro({pomodoro, setPomodoro}){
  // simple pomodoro state inside App in this prototype (controls passed)
  return (
    <div style={{maxWidth:520, margin:'0 auto', background:'#fff', padding:20, borderRadius:8}}>
      <h2>Pomodoro</h2>
      <div style={{fontFamily:'monospace', fontSize:48}}>{String(pomodoro.minutes).padStart(2,'0')}:{String(pomodoro.seconds).padStart(2,'0')}</div>
      <p>Modo: {pomodoro.mode}</p>
      <div style={{marginTop:10}}>
        <button onClick={()=> setPomodoro(p=>({...p, running:!p.running}))} style={{...navBtn, background:'#5b2b8a', color:'#fff'}}>{pomodoro.running?'Pausar':'Iniciar'}</button>
        <button onClick={()=> setPomodoro({running:false, mode:'focus', minutes:25, seconds:0})} style={navBtn}>Reset</button>
      </div>
      <p style={{fontSize:12, color:'#666', marginTop:10}}>Dicas: combine SQ3R e Feynman durante ciclos de estudo.</p>
    </div>
  );
}

function Study({displayText, setCurrentVerse, addFlash}){
  const [note, setNote] = React.useState('');
  const [book, setBook] = React.useState('Genesis');
  const [chapter, setChapter] = React.useState('1');
  const [verse, setVerse] = React.useState('1');
  return (
    <div style={{display:'grid', gridTemplateColumns:'1fr 320px', gap:12}}>
      <div style={{background:'#fff', padding:12, borderRadius:8}}>
        <h3>Estudo Ativo (SQ3R)</h3>
        <p><strong>Survey:</strong> Olhe o contexto. <strong>Question:</strong> Faça perguntas. <strong>Read:</strong> Leia. <strong>Recite:</strong> Explique com suas palavras. <strong>Review:</strong> Revise.</p>
        <div style={{marginTop:8}}>
          <label>Livro: <input value={book} onChange={e=>setBook(e.target.value)} /></label>
          <label style={{marginLeft:8}}>Cap: <input value={chapter} onChange={e=>setChapter(e.target.value)} style={{width:60}}/></label>
          <label style={{marginLeft:8}}>Vers: <input value={verse} onChange={e=>setVerse(e.target.value)} style={{width:60}}/></label>
          <button onClick={()=> setCurrentVerse({book, chapter, verse})} style={{...navBtn, marginLeft:8}}>Carregar</button>
        </div>
        <div style={{marginTop:12, minHeight:120, background:'#f7f3ff', padding:12, borderRadius:6}}>{displayText || 'Selecione um versículo e clique em Carregar.'}</div>
        <textarea placeholder='Escreva sua explicação (Feynman)...' value={note} onChange={e=>setNote(e.target.value)} style={{width:'100%', minHeight:120, marginTop:8}} />
        <div style={{marginTop:8}}>
          <button onClick={()=>{ addFlash('Pergunta: O que diz o texto?', 'Resposta: Resumo curto'); setNote(''); }} style={{...navBtn, background:'#5b2b8a', color:'#fff'}}>Salvar nota e criar flashcard</button>
        </div>
      </div>
      <aside style={{background:'#fff', padding:12, borderRadius:8}}>
        <h4>Recursos</h4>
        <p>Flashcards e notas aparecem aqui.</p>
      </aside>
    </div>
  );
}

function Theology(){ return (<div style={{background:'#fff', padding:12, borderRadius:8}}><h2>Cursos Teológicos</h2>{THEOLOGY_MODULES.map(m=>(<div key={m.id} style={{padding:10, borderBottom:'1px solid #f0f0f0'}}><h3>{m.title}</h3><p style={{color:'#666'}}>{m.lessons.length} aulas</p><button style={{...navBtn, background:'#ffd700'}}>Iniciar</button></div>))}</div>); }
