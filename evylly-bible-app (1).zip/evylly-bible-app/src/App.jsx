import React, { useState, useEffect, useRef } from "react";

// Evylly Bible Study App - Single-file React component (preview)
// Usa Tailwind para estilização. Importações de componentes externos (shadcn/ui, lucide-react) são exemplos - adapte conforme seu projeto.

export default function App() {
  // ----- Estado global simples -----
  const [view, setView] = useState("home");
  const [readingPlan, setReadingPlan] = useState(generateDefaultPlan());
  const [currentDay, setCurrentDay] = useState(getTodayIndex());
  const [notes, setNotes] = useState(loadFromStorage("ev_notes", {}));
  const [flashcards, setFlashcards] = useState(loadFromStorage("ev_flashcards", []));
  const [pomodoro, setPomodoro] = useState({ running: false, mode: "focus", minutes: 25, seconds: 0 });
  const pomodoroTimer = useRef(null);

  useEffect(() => {
    saveToStorage("ev_notes", notes);
  }, [notes]);
  useEffect(() => {
    saveToStorage("ev_flashcards", flashcards);
  }, [flashcards]);

  // ----- Pomodoro logic -----
  useEffect(() => {
    if (!pomodoro.running) return;
    pomodoroTimer.current = setInterval(() => {
      setPomodoro(prev => {
        const total = prev.minutes * 60 + prev.seconds - 1;
        if (total < 0) {
          // switch mode
          const nextMode = prev.mode === "focus" ? "break" : "focus";
          const minutes = nextMode === "focus" ? 25 : 5;
          return { ...prev, mode: nextMode, minutes, seconds: 0 };
        }
        return { ...prev, minutes: Math.floor(total / 60), seconds: total % 60 };
      });
    }, 1000);
    return () => clearInterval(pomodoroTimer.current);
  }, [pomodoro.running]);

  // ----- Helpers -----
  function togglePomodoro() {
    setPomodoro(p => ({ ...p, running: !p.running }));
  }
  function resetPomodoro() {
    setPomodoro({ running: false, mode: "focus", minutes: 25, seconds: 0 });
  }

  // ----- Simple UI screens -----
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-purple-100 text-gray-900">
      <header className="p-4 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-purple-800">Evylly Study — Bíblia Ativa</h1>
        <nav className="space-x-2">
          <button onClick={() => setView("home")} className="px-3 py-1 rounded-md">Home</button>
          <button onClick={() => setView("plan")} className="px-3 py-1 rounded-md">Plano</button>
          <button onClick={() => setView("pomodoro")} className="px-3 py-1 rounded-md">Pomodoro</button>
          <button onClick={() => setView("study")} className="px-3 py-1 rounded-md">Estudo Ativo</button>
          <button onClick={() => setView("courses")} className="px-3 py-1 rounded-md">Teologia</button>
        </nav>
      </header>

      <main className="p-6">
        {view === "home" && (
          <Home setView={setView} currentDay={currentDay} readingPlan={readingPlan} />
        )}
        {view === "plan" && (
          <ReadingPlan
            readingPlan={readingPlan}
            setReadingPlan={setReadingPlan}
            currentDay={currentDay}
            setCurrentDay={setCurrentDay}
          />
        )}
        {view === "pomodoro" && (
          <Pomodoro
            pomodoro={pomodoro}
            togglePomodoro={togglePomodoro}
            resetPomodoro={resetPomodoro}
          />
        )}
        {view === "study" && (
          <ActiveStudy
            notes={notes}
            setNotes={setNotes}
            flashcards={flashcards}
            setFlashcards={setFlashcards}
          />
        )}
        {view === "courses" && <TheologyCourses />}
      </main>

      <footer className="p-4 text-center text-sm text-gray-600">Protótipo — funcionalidades: plano de leitura, pomodoro, estudo ativo, flashcards, notas e cursos teológicos.</footer>
    </div>
  );
}

// ----------------- Componentes menores -----------------
function Home({ setView, currentDay, readingPlan }) {
  const today = readingPlan[currentDay] || { title: "Dia concluído" };
  return (
    <div className="space-y-6">
      <section className="bg-white p-4 rounded-lg shadow-sm">
        <h2 className="text-xl font-semibold">Leitura do dia</h2>
        <p className="text-sm text-gray-600">{today.title}</p>
        <div className="mt-3 flex gap-2">
          <button onClick={() => setView("plan")} className="px-3 py-1 rounded bg-purple-700 text-white">Abrir plano</button>
          <button onClick={() => setView("study")} className="px-3 py-1 rounded border">Estudar agora</button>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card title="Pomodoro" subtitle="Concentre-se com ciclos curtos" onClick={() => setView("pomodoro")} />
        <Card title="Flashcards" subtitle="Revisão por repetição espaçada" onClick={() => setView("study")} />
        <Card title="Cursos" subtitle="Aprofunde em teologia" onClick={() => setView("courses")} />
      </section>
    </div>
  );
}
function Card({ title, subtitle, onClick }) {
  return (
    <div className="bg-white p-4 rounded-lg shadow-sm cursor-pointer" onClick={onClick}>
      <h3 className="font-semibold">{title}</h3>
      <p className="text-sm text-gray-600">{subtitle}</p>
    </div>
  );
}

function ReadingPlan({ readingPlan, setReadingPlan, currentDay, setCurrentDay }) {
  function markDone(index) {
    setCurrentDay(index + 1);
  }
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold">Plano de leitura (exemplo: 365 dias)</h2>
      <ul className="space-y-2 max-h-96 overflow-auto">
        {readingPlan.map((r, i) => (
          <li key={i} className={`p-3 rounded ${i === currentDay ? "bg-purple-50" : "bg-white"}`}>
            <div className="flex justify-between">
              <div>
                <strong>Dia {i + 1}:</strong> {r.title}
              </div>
              <div className="flex gap-2">
                <button onClick={() => markDone(i)} className="px-2 py-1 rounded border">Concluir</button>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

function Pomodoro({ pomodoro, togglePomodoro, resetPomodoro }) {
  return (
    <div className="max-w-md mx-auto bg-white p-6 rounded-lg shadow-sm text-center">
      <h2 className="text-xl font-semibold mb-4">Pomodoro</h2>
      <div className="text-4xl font-mono">{String(pomodoro.minutes).padStart(2, "0")}:{String(pomodoro.seconds).padStart(2, "0")}</div>
      <p className="text-sm mt-2">Modo: {pomodoro.mode}</p>
      <div className="mt-4 flex justify-center gap-3">
        <button onClick={togglePomodoro} className="px-4 py-2 rounded bg-purple-700 text-white">{pomodoro.running ? "Pausar" : "Iniciar"}</button>
        <button onClick={resetPomodoro} className="px-4 py-2 rounded border">Reset</button>
      </div>
      <p className="text-xs text-gray-500 mt-3">Dica: use ciclos de 25/5 ou personalize para leitura bíblica (ex: 45/15 para estudo profundo).</p>
    </div>
  );
}

function ActiveStudy({ notes, setNotes, flashcards, setFlashcards }) {
  const [bookQuery, setBookQuery] = useState("");
  const [currentNoteText, setCurrentNoteText] = useState("");

  function addNote() {
    const id = Date.now();
    setNotes({ ...notes, [id]: { text: currentNoteText, created: new Date().toISOString() } });
    setCurrentNoteText(""");
  }
  function addFlashcard(front, back) {
    setFlashcards(prev => [...prev, { id: Date.now(), front, back, efactor: 2.5 }]);
  }

  return (
    <div className="grid md:grid-cols-2 gap-4">
      <section className="bg-white p-4 rounded-lg">
        <h3 className="font-semibold">Estudo ativo</h3>
        <p className="text-sm text-gray-600">Ferramentas: perguntas reflexivas, anotações, marcação, resumos e flashcards.</p>
        <div className="mt-3">
          <input placeholder="Pesquisar livro / capítulo" value={bookQuery} onChange={e => setBookQuery(e.target.value)} className="w-full p-2 border rounded" />
        </div>
        <div className="mt-3">
          <textarea value={currentNoteText} onChange={e => setCurrentNoteText(e.target.value)} className="w-full p-2 border rounded" rows={6} placeholder="Escreva suas anotações ou reflexões..." />
          <div className="flex gap-2 mt-2">
            <button onClick={addNote} className="px-3 py-1 rounded bg-purple-700 text-white">Salvar nota</button>
            <button onClick={() => addFlashcard("O que diz o texto?", "Resumo curto...") } className="px-3 py-1 rounded border">Criar flashcard exemplo</button>
          </div>
        </div>
      </section>

      <section className="bg-white p-4 rounded-lg max-h-96 overflow-auto">
        <h4 className="font-semibold">Minhas notas</h4>
        <ul className="space-y-2 mt-2">
          {Object.entries(notes).length === 0 && <li className="text-sm text-gray-500">Nenhuma nota ainda</li>}
          {Object.entries(notes).map(([id, n]) => (
            <li key={id} className="p-2 border rounded">
              <div className="text-sm text-gray-700">{n.text}</div>
              <div className="text-xs text-gray-400 mt-1">{new Date(n.created).toLocaleString()}</div>
            </li>
          ))}
        </ul>

        <div className="mt-4">
          <h5 className="font-semibold">Flashcards (revisão)</h5>
          <ul className="space-y-2 mt-2">
            {flashcards.length === 0 && <li className="text-sm text-gray-500">Nenhum flashcard</li>}
            {flashcards.map(f => (
              <li key={f.id} className="p-2 border rounded">
                <div className="font-semibold">{f.front}</div>
                <div className="text-sm text-gray-600">{f.back}</div>
              </li>
            ))}
          </ul>
        </div>
      </section>
    </div>
  );
}

function TheologyCourses() {
  const courses = [
    { id: 1, title: "Introdução à Teologia Bíblica", lessons: 12 },
    { id: 2, title: "Hermenêutica Prática", lessons: 8 },
    { id: 3, title: "Teologia Sistemática - Resumo", lessons: 20 },
  ];
  return (
    <div className="bg-white p-4 rounded-lg">
      <h2 className="text-xl font-semibold">Cursos Teológicos</h2>
      <p className="text-sm text-gray-600">Módulos com leituras, quizzes e atividades práticas.</p>
      <ul className="mt-3 space-y-2">
        {courses.map(c => (
          <li key={c.id} className="p-3 border rounded flex justify-between items-center">
            <div>
              <div className="font-semibold">{c.title}</div>
              <div className="text-xs text-gray-500">{c.lessons} aulas</div>
            </div>
            <button className="px-3 py-1 rounded bg-purple-700 text-white">Iniciar</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

// ----------------- Utilitários -----------------
function generateDefaultPlan() {
  // Gera um plano simples de 30 dias como exemplo. Em produção, gere 365 dias cobrindo toda a Bíblia
  const books = ["Gênesis", "Êxodo", "Levítico", "Números", "Deuteronômio", "Salmos", "Mateus", "Marcos", "Lucas", "João"];
  return Array.from({ length: 30 }).map((_, i) => ({ title: `${books[i % books.length]} - leitura diária (capítulos exemplo)` }));
}
function getTodayIndex() {
  // Simples: retorna 0 para usar como exemplo
  return 0;
}
function saveToStorage(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { }
}
function loadFromStorage(key, fallback) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch (e) { return fallback; }
}
